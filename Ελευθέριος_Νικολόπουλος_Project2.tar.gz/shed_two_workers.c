#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int p1[2], p2[2], p3[2], p4[2], p5[2], p6[2];
float result1 = 0, result2 = 0, result3 = 0, result4 = 0, result5 = 0, result6 = 0;
float x;

// Χειριστής σήματος για το πρώτο παιδί
void sigusr1_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p1[0], &number1, sizeof(float));
    read(p1[0], &operator, sizeof(char));
    read(p1[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result1 = number1 + number2;
    else if (operator == '-')
        result1 = number1 - number2;
    else if (operator == '*')
        result1 = number1 * number2;
    else if (operator == '/')
        result1 = number1 / number2;

    close(p1[0]);
}

// Χειριστής σήματος για το δεύτερο παιδί
void sigusr2_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p2[0], &number1, sizeof(float));
    read(p2[0], &operator, sizeof(char));
    read(p2[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result2 = result1 + number2;
    else if (operator == '-')
        result2 = result1 - number2;
    else if (operator == '*')
        result2 = result1 * number2;
    else if (operator == '/')
        result2 = result1 / number2;

    close(p2[0]);
}

/// Χειριστής σήματος για το τρίτο παιδί
void sigusr3_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p3[0], &number1, sizeof(float));
    read(p3[0], &operator, sizeof(char));
    read(p3[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result3 = result2 + number2;
    else if (operator == '-')
        result3 = result2 - number2;
    else if (operator == '*')
        result3 = result2 * number2;
    else if (operator == '/')
        result3 = result2 / number2;

    close(p3[0]);
}

// Χειριστής σήματος για το τέταρτο παιδί
void sigusr4_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p4[0], &number1, sizeof(float));
    read(p4[0], &operator, sizeof(char));
    read(p4[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result4 = result3 + number2;
    else if (operator == '-')
        result4 = result3 - number2;
    else if (operator == '*')
        result4 = result3 * number2;
    else if (operator == '/')
        result4 = result3 / number2;

    close(p4[0]);
}

// Χειριστής σήματος για το πέμπτο παιδί
void sigusr5_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p5[0], &number1, sizeof(float));
    read(p5[0], &operator, sizeof(char));
    read(p5[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result5 = result4 + number2;
    else if (operator == '-')
        result5 = result4 - number2;
    else if (operator == '*')
        result5 = result4 * number2;
    else if (operator == '/')
        result5 = result4 / number2;

    close(p5[0]);
    }
    
    // Χειριστής σήματος για το πέμπτο παιδί
void sigusr6_handler(int signum) {
    float number1, number2;
    char operator;

    // Διάβασμα αριθμών και τελεστή από τη σωλήνωση
    read(p6[0], &number1, sizeof(float));
    read(p6[0], &operator, sizeof(char));
    read(p6[0], &number2, sizeof(float));

    // Υπολογισμός του αποτελέσματος
    if (operator == '+')
        result6 = result5 + number2;
    else if (operator == '-')
        result6 = result5 - number2;
    else if (operator == '*')
        result6 = result5 * number2;
    else if (operator == '/')
        result6 = result5 / number2;

    close(p5[0]);
}



// Συνάρτηση για την αποστολή εργασίας στη σωλήνωση
void send_task(float number1, char operator, float number2, int pipe_write) {
    write(pipe_write, &number1, sizeof(float));
    write(pipe_write, &operator, sizeof(char));
    write(pipe_write, &number2, sizeof(float));
}

int main() {
    if (pipe(p1) == -1 || pipe(p2) == -1 || pipe(p3) == -1 || pipe(p4) == -1 || pipe(p5) == -1 || pipe(p6) == -1) {
        printf("Σφάλμα στη δημιουργία των αγωγών.\n");
        return 1;
    }

    // Ορισμός χειριστών σημάτων
    signal(SIGUSR1, sigusr1_handler);
    signal(SIGUSR2, sigusr2_handler);
    signal(SIGUSR1 + 1, sigusr3_handler);
    signal(SIGUSR2 + 1, sigusr4_handler);
    signal(SIGUSR1 + 11, sigusr5_handler);
    signal(SIGUSR2 + 11, sigusr6_handler);


    pid_t pid1 = fork();
    if (pid1 == 0) {
        close(p1[0]);

        // Ανάθεση αριθμητικής έκφρασης X στο πρώτο παιδί
        float number1 = 2;
        char operator = '*';
        float number2 = 7;

        send_task(number1, operator, number2, p1[1]);

        close(p1[1]);

        // Αποστολή σήματος SIGUSR1 στη γονική διεργασία
        kill(getppid(), SIGUSR1);
    } else if (pid1 > 0) {
        close(p1[1]);
        sleep(1);

        pid_t pid2 = fork();
        if (pid2 == 0) {
            // Παιδική διεργασία 2 (Worker 2)
            close(p2[0]);

            // Ανάθεση αριθμητικής έκφρασης X στο δεύτερο παιδί
            float number1 = result1;
            char operator = '+';
            float number2 = 3 * 6;

            send_task(number1, operator, number2, p2[1]);

            close(p2[1]);

            // Αποστολή σήματος SIGUSR2 στη γονική διεργασία
            kill(getppid(), SIGUSR2);
        } else if (pid2 > 0) {
            close(p2[1]);

            // Αναμονή για την ολοκλήρωση του πρώτου παιδιού
            wait(NULL);

            // Αναμονή για σήμα από το παιδί 2
            sleep(1);

            pid_t pid3 = fork();
            if (pid3 == 0) {
                // Παιδική διεργασία 3 (Worker 3)
                close(p3[0]);

                // Ανάθεση αριθμητικής έκφρασης X στο τρίτο παιδί
                float number1 = result2;
                char operator = '-';
                float number2 = 2*2;

                send_task(number1, operator, number2, p3[1]);

                close(p3[1]);

                // Αποστολή σήματος SIGUSR3 στη γονική διεργασία
                kill(getppid(), SIGUSR1 + 1);
            } else if (pid3 > 0) {
                close(p3[1]);
                sleep(1);

                pid_t pid4 = fork();
                if (pid4 == 0) {
                    // Παιδική διεργασία 4 (Worker 4)
                    close(p4[0]);

                    // Ανάθεση αριθμητικής έκφρασης X στο τέταρτο παιδί
                    float number1 = result3;
                    char operator = '+';
                    float number2 = 3 * 3;

                    send_task(number1, operator, number2, p4[1]);

                    close(p4[1]);

                    // Αποστολή σήματος SIGUSR4 στη γονική διεργασία
                    kill(getppid(), SIGUSR2 + 1);
                } else if (pid4 > 0) {
                    close(p4[1]);

                    // Αναμονή για σήμα από το παιδί 4
                    sleep(1);
                    
                    pid_t pid5 = fork();
                if (pid5 == 0) {
                    // Παιδική διεργασία 4 (Worker 4)
                    close(p5[0]);

                    // Ανάθεση αριθμητικής έκφρασης X στο τέταρτο παιδί
                    float number1 = result4;
                    char operator = '-';
                    float number2 = 2;

                    send_task(number1, operator, number2, p5[1]);

                    close(p5[1]);

                    // Αποστολή σήματος SIGUSR4 στη γονική διεργασία
                    kill(getppid(), SIGUSR1 + 11);
                } else if (pid5 > 0) {
                    close(p5[1]);

                    sleep(1);
                    
                 pid_t pid6 = fork();
                if (pid6 == 0) {
                    // Παιδική διεργασία 4 (Worker 4)
                    close(p6[0]);

                    // Ανάθεση αριθμητικής έκφρασης X στο τέταρτο παιδί
                    float number1 = result5;
                    char operator = '/';
                    float number2 = 2;

                    send_task(number1, operator, number2, p6[1]);

                    close(p6[1]);

                    // Αποστολή σήματος SIGUSR4 στη γονική διεργασία
                    kill(getppid(), SIGUSR2 + 11);
                } else if (pid6 > 0) {
                    close(p6[1]);
		    wait(NULL);
                    sleep(1);
                   

                    printf("Το τελικό αποτέλεσμα είναι: %.2f\n", result6);
                  } else {
                    printf("Σφάλμα στη δημιουργία του πεμπτου παιδιού.\n");
                    return 1;
                } 
                    } else {
                    printf("Σφάλμα στη δημιουργία του πεμπτου παιδιού.\n");
                    return 1;
                }
                } else {
                    printf("Σφάλμα στη δημιουργία του τέταρτου παιδιού.\n");
                    return 1;
                }
            } else {
                printf("Σφάλμα στη δημιουργία του τρίτου παιδιού.\n");
                return 1;
            }
        } else {
            printf("Σφάλμα στη δημιουργία του δεύτερου παιδιού.\n");
            return 1;
        }
    } else {
        printf("Σφάλμα στη δημιουργία του πρώτου παιδιού.\n");
        return 1;
    }

    return 0;
}

